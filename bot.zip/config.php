<?php
class Config {
	static $User = array(
		"user"=>'loleventvods',
		"passwd"=>"vodsteam",
		"api_type"=>"json",
	);
	static $API = array(
		"gg"=>"http://www.gosugamers.net/api/matches?apiKey=8d444a60d1c27e8113d2c28434f7b004&game=lol",
		"googl"=>"AIzaSyB58png8MHNxijB5nc8dzbnB-8FrTlSt5Y",
	);
}
?>